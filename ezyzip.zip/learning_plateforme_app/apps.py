from django.apps import AppConfig


class LearningPlateformeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'learning_plateforme_app'
