from django.contrib import messages
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect,render
from django.template.loader import render_to_string
from learning_plateforme_app.models import Author, Categories, Course, Level, UserCourse, Video
from django.db.models import Sum

def BASE(request):
    return render(request,'base.html')

def HOME(request):
    categories = Categories.objects.all().order_by('id')[0:5]
    cours = Course.objects.filter(status = 'PUBLISH').order_by('-id')
    
    context = {
        'categories' : categories,
        'cours' : cours,
    }

    return render(request,'main/home.html',context)

def SINGLE_COURSE(request):
    categories = Categories.get_all_categories(Categories)
    authors = Author.objects.all()
    level = Level.objects.all()
    course = Course.objects.all()
    free_course_count = Course.objects.filter(price = 0).count()
    paid_course_count = Course.objects.filter(price__gte = 1).count()

    context = {
        'categories' : categories,
        'authors' : authors,
        'level' : level,
        'course' : course,
        'free_course_count' : free_course_count,
        'paid_course_count' : paid_course_count,
    }

    return render(request,'main/single_course.html',context)

def filter_data(request):
    category = request.GET.getlist('categories[]')
    level = request.GET.getlist('level[]')
    price = request.GET.getlist('price[]')

    if price == ['PriceFree']:
        course = Course.objects.filter(price=0)
    elif price == ['PricePaid']:
        course = Course.objects.filter(price__gte=1)
    elif price == ['PriceAll']:
        course = Course.objects.all()
    elif category:
        course = Course.objects.filter(category__id__in = category).order_by('-id')
    elif level:
        course = Course.objects.filter(level__id__in = level).order_by('-id')
    else:
        course = Course.objects.all().order_by('-id')

    context = {
        'course': course
    }
    t = render_to_string('ajax/course.html', context)
    return JsonResponse({'data': t})

def CONTACT_US(request):
    categories = Categories.get_all_categories(Categories)

    context = {
        'categories':categories
    }
    return render(request,'main/contact_us.html',context)

def ABOUT_US(request):
    categories = Categories.get_all_categories(Categories)

    context = {
        'categories':categories
    }
    return render(request,'main/about_us.html',context)

def SEARCH_COURSE(request):
    query = request.GET['query']
    cours = Course.objects.filter(title__icontains = query)
    categories = Categories.get_all_categories(Categories)

    context = {
        'cours' : cours,
        'categories':categories
    }

    return render(request, 'search/search.html',context)

def DISPLAY_COURSE(request,slug):
    cours = Course.objects.filter(slug = slug).first()
    categories = Categories.get_all_categories(Categories)

    context = {
        'cours' : cours,
        'categories':categories
    }

    return render(request, 'search/search.html',context)

def COURSE_DETAILS(request, slug):
    course = get_object_or_404(Course, slug=slug)
    categories = Categories.get_all_categories(Categories)
    time_duration = Video.objects.filter(course__slug=slug).aggregate(sum=Sum('time_duration'))

    # Vérifier si l'utilisateur est inscrit au cours
    try:
        check_enroll = UserCourse.objects.get(user=request.user, course=course)
    except UserCourse.DoesNotExist:
        check_enroll = None

    # Utilisez la méthode get_videos_for_user pour obtenir les vidéos appropriées
    videos = course.get_videos_for_user(request.user)

    context = {
        'course': course,
        'categories': categories,
        'time_duration': time_duration,
        'check_enroll': check_enroll,
        'videos': videos,
    }
    return render(request, 'course/course_details.html', context)


def PAGE_NOT_FOUND(request):
    categories = Categories.get_all_categories(Categories)

    context = {
        'categories':categories
    }
    return render(request, 'error/404.html',context)

def CHECKOUT(request,slug):
    course = Course.objects.get(slug = slug)
    
    
    course = UserCourse(
        user = request.user,
        course = course,
    )
    course.save()
    messages.success(request,"Inscription au cours effectuée avec succès")
    return redirect('my_course')
    # return render(request,'checkout/checkout.html')

def MY_COURSE(request):
    categories = Categories.get_all_categories(Categories)
    course = UserCourse.objects.filter(user = request.user)

    context = {
        'course':course,
        'categories':categories,
    }
    return render(request,'course/my_course.html',context)

def WATCH_COURSE(request,slug):
    course = Course.objects.filter(slug = slug)
    lecture = request.GET.get('lecture')
    video = Video.objects.get(id = lecture)

    lecture_pre = int(lecture) - 1
    try:
        video_pre = Video.objects.get(id=lecture_pre)
    except Video.DoesNotExist:
        video_pre = None  # Aucune vidéo précédente

    lecture_sui = int(lecture) + 1
    try:
        video_sui = Video.objects.get(id=lecture_sui)
    except Video.DoesNotExist:
        video_sui = None  # Aucune vidéo suivante

    if course.exists():
        course = course.first()
    else:
        return redirect('404')
    
    context = {
        'course' : course,
        'video' : video,
        'video_pre' : video_pre,
        'video_sui' : video_sui,
    }
    return render(request,'course/watch_course.html',context)